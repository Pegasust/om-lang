import asts


def program(ast: asts.Program):
    pass
