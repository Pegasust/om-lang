import asts

def program(a: asts.Program):
	pass
